const handleUpdate = async () => {
    setLoading(true);
    try {
      await updateBook(book.id, {
        ItemType: 'book',
        ItemTitle: book.title,
        ItemAuther: book.author,
        status: book.status,
        imageUrl: book.imgurl ?? '',
      });
      alert('Book updated successfully ✅');
    } catch (err) {
      console.error('Failed to update book:', err);
      alert('Update faile');
    } finally {
      setLoading(false);
    }
  };
