"use server"
import React from 'react'

function BorrowBook() {
  return (
    <div>BorrowBook</div>
  )
}

export default BorrowBook