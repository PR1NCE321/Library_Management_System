"use server";
import { PrismaClient, Status } from "@/app/generated/prisma";

const prisma = new PrismaClient();

export async function createBook(form: {
  ItemType: string;
  ItemTitle: string;
  ItemAuther: string;
  status: string;
  imageUrl?: string;
}) {
  await prisma.items.create({
    data: {
      ItemType: form.ItemType,
      ItemTitle: form.ItemTitle,
      ItemAuther: form.ItemAuther,
      status: form.status as Status,
      imageUrl: form.imageUrl || null,
    },
  });
}
