"use server";
import { PrismaClient, Status } from "@/app/generated/prisma";

const prisma = new PrismaClient();

export async function updateBook(bookId: number, form: {
  ItemType: string;
  ItemTitle: string;
  ItemAuther: string;
  status: string;
  imageUrl?: string;
}) {
  const validStatus = form.status === "available" || form.status === "borrowed"
    ? form.status as Status
    : "available";

  await prisma.items.update({
    where: { ItemID: bookId },
    data: {
      ItemType: form.ItemType,
      ItemTitle: form.ItemTitle,
      ItemAuther: form.ItemAuther,
      status: validStatus,
      imageUrl: form.imageUrl || null,
    },
  });
}
